# Go to http://dev.twitter.com and create an app.
# The consumer key and secret will be generated for you after
consumer_key="xiC2E8rb40oMjldSv4C0qWJvy"
consumer_secret="L43qRzS6LfFf3Qr4dnc7pQXdTBwfMfzKqmUg53KHwOPeX8i8TB"

# After the step above, you will be redirected to your app's page.
# Create an access token under the the "Your access token" section
access_token="73145615-bFALchgckqR21QZliN5i23vsFNRKBMjDBJN3qvSeF"
access_token_secret="8prscjZZbplgUQyq6qBPkaCG1T03Jp8WmyI7MEDDNuzkZ"
